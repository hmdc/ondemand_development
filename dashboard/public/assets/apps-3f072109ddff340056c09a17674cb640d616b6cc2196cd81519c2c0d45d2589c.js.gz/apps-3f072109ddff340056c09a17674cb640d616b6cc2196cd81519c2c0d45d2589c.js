// app/javascript/apps.js
jQuery(function() {
  $("#all-apps-table").DataTable({
    stateSave: true
  });
});
//# sourceMappingURL=/pun/sys/ood/assets/apps.js-960afbe5679f6265d73b01531f876b940ffb221b9c97432ad42111183e69c98b.map
//!
;
